

def enlarge(n):
    reture n * 100
